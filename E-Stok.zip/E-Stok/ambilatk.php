<?php
    require 'dbconnect.php';
    require 'cek.php';
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>E-FORM ATK</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

        <!-- Script CDN Bootstrap -->
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />

        <!-- Datepicker Library -->
        <script src="Library/datepicker/js/bootstrap-datepicker.js"></script>

        <!-- jQuery library -->
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

        <!-- Font -->
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>

        <script src="text/javascript">
        $(document).ready(function(){
            $("#course").change(function(){
                var course_id=$(this).val();
                $.ajax({
                    url: "action.php",
                    method: "POST",
                    data: {courseID:course_id},
                    success: function(data){
                        $("language").html(data);
                    }
                });
            });
        });
        </script>

        <script>
        $(document).ready(function() {
            $(".add_item_btn").click(function(e) {
                e.preventDefault();
                $("#show_item").append
                    (`<div class="row append_item">
                        <div class="col-md-12 mb-3">
                            <label>Nama Pengambil</label> 
                            <input text="number" name="nama_pengambil[]" class="form-control" required>
                        </div>

                        <div class="col-md-12 mb-3">
                            <label>Pilih Barang</label> 
                            <select name="barangnya[]" class="form-control">
                                <?php
                                    $ambilsemuadatanya = mysqli_query($conn,"select * from stock");
                                    while ($fetcharray = mysqli_fetch_array($ambilsemuadatanya)){
                                        $namabarangnya = $fetcharray['namabarang'];
                                        $idbarangnya   = $fetcharray['idbarang'];
                                ?>
                                
                                <option value = "<?=$idbarangnya;?>"> <?=$namabarangnya;?> </option>

                                <?php
                                    }
                                ?>
                            </select>
                        </div>

                        <div class="col-md-12 mb-3">
                            <label>Jumlah Barang</label> 
                            <input text="number" name="jumlah_barang[]" class="form-control" required>
                        </div>

                        <div class="col-md-2 mb-3 d-grid">
                            <button class="btn btn-danger remove_item_btn">Hapus</button>
                        </div>
                    </div>`);
                });

                $(document).on('click', '.remove_item_btn', function(e) {
                    e.preventDefault();
                    let row_item = $(this).parent().parent();
                    $(row_item).remove();
                    
                });

                // ajax request to insert all form data
                $("#add_form").submit(function(e) {
                    e.preventDefault();
                    $("#add_btn").val('Adding...');
                    $.ajax({
                        url: '../success.php',
                        method: 'post',
                        data: $(this).serialize(),
                        success:function(response){
                            $("#add_btn").val('Add');
                            $("#add_form")[0].reset();
                            $(".append_item").remove();
                            $("#show_alert").html(`<div class="alert alert-success" role="alert">${response}</div>`);
                        }
                    });
                });
            });
        </script>
    </head>

    <body class="sb-nav-fixed">
        <div class="card border-primary mb-5 shadow">
            <div id="layoutSidenav_content">
                <main>
                    <div class="row my-4">
                        <div class="col-lg-10 mx-auto">
                            <div class="container px-4 justify-content-center">
                                <div align="center">
                                    <img src="Images/dkj.jpg" width="20%" style="margin-top:0%"/>
                                    <h1 class="mt-4">"FORM PENGAMBILAN ATK DKJ 2023/2024"</h1>
                                        <script type='text/javascript'>                    
                                                var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                                                var myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
                                                var date = new Date();
                                                var day = date.getDate();
                                                var month = date.getMonth();
                                                var thisDay = date.getDay(),
                                                    thisDay = myDays[thisDay];
                                                var yy = date.getYear();
                                                var year = (yy < 1000) ? yy + 1900 : yy;
                                                document.write(thisDay + ', ' + day + ' ' + months[month] + ' ' + year);		
                                        </script>
                                        
                                        <?php
                                            date_default_timezone_set("Asia/jakarta");
                                        ?>
                                        | <b><span id="jam" style="font-size:24"></span></b>

                                        <script type="text/javascript">
                                            window.onload = function() { jam(); }
                                        
                                            function jam() {
                                                var e = document.getElementById('jam'),
                                                d = new Date(), h, m, s;
                                                h = d.getHours();
                                                m = set(d.getMinutes());
                                                s = set(d.getSeconds());
                                        
                                                e.innerHTML = h +':'+ m +':'+ s;
                                        
                                                setTimeout('jam()', 1000);
                                            }
                                        
                                            function set(e) {
                                                e = e < 10 ? '0'+ e : e;
                                                return e;
                                            }
                                        </script>
                                    </br></br> 
                                </div>
                        
                                <div class="card mb-2">
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
                                        + Input ATK
                                    </button>
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>
        
                <div class="modal fade" id="myModal">
                    <div class="modal-dialog">
                        <div class="modal-content">    
                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title">Input Barang ATK</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            
                            <!-- Modal body -->
                            <form method="post">
                                <div class="modal-body">
                                    <div class="col-md-12 mb-3">
                                        <label>Nama</label> 
                                        <input text="text" name="nama_pengambil" class="form-control" required>
                                    </div>

                                    <div class="col-md-12 mb-3">
                                        <label>Pilih Department</label> 
                                        <select name="department" value="<?=$department;?>" class="custom-select form-control" required></br>
                                            <option selected>Pilih Department</option>
                                            <option value="Accounting">Accounting</option>
                                            <option value="Finance">Finance</option>
                                            <option value="HRGA">HRGA</option>
                                            <option value="Logistik">Logistik</option>
                                            <option value="Maintenance">Maintenance</option>
                                            <option value="Marketing">Marketing</option>
                                            <option value="QC">QC</option>
                                            <option value="QHSE">QHSE</option>
                                            <option value="PPIC">PPIC</option>
                                            <option value="Produksi">Produksi</option>
                                            <option value="Purchasing">Purchasing</option>
                                            <option value="RND">RND</option>
                                        </select>
                                        <!-- <input type="date" name="tanggal[]" class="form-control datepicker" required> -->
                                    </div>

                                    <div class="col-md-12 mb-3">
                                        <label>Pilih Barang</label> 
                                        <select name="barangnya" class="form-control">
                                            <?php
                                                $ambilsemuadatanya = mysqli_query($conn,"select * from stock");
                                                while ($fetcharray = mysqli_fetch_array($ambilsemuadatanya)){
                                                    $namabarangnya = $fetcharray['namabarang'];
                                                    $idbarangnya   = $fetcharray['idbarang'];
                                            ?>

                                            <option value = "<?=$idbarangnya;?>"> <?=$namabarangnya;?> </option>

                                            <?php
                                                }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="col-md-12 mb-3">
                                        <label>Jumlah Barang</label> 
                                        <input type="number" name="qty" class="form-control" required>
                                    </div>  

                                    <!-- <div class="col-md-12 mb-3 d-grid">
                                        <button class="btn btn-success w-100 add_item_btn">Add More</button>
                                    </div>  
                                     -->
                                    <div class="col-md-12 mb-3">
                                        <button type="submit" class="btn btn-primary w-100" name="barangkeluar">Submit</button>
                                    </div>  
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                </main>
                     

                        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
                        <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
                        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
                        <script src="js/scripts.js"></script>
                        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
                        <script src="assets/demo/chart-area-demo.js"></script>
                        <script src="assets/demo/chart-bar-demo.js"></script>
                        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
                        <script src="js/datatables-simple-demo.js"></script>
                    </div>       

    </body>
</html>
