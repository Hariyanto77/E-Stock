<?php
    require 'dbconnect.php';
    

    //Cek Login
    if(isset($_POST['login'])){
        $username = $_POST['username'];
        $password = $_POST['password'];

        //Mencocokan dengan database
        $cekdatabase = mysqli_query($conn, "SELECT * FROM login where username ='$username' and password ='$password'");

        //Hitung jumlah data
        $hitung = mysqli_num_rows($cekdatabase);

        if($hitung > 0){
            $_SESSION['log'] = 'True';
            header('location:index.php');
        }  else {
            header('location:login.php');
        };
};

if(!isset($_SESSION['log'])){
} else {
    header('location:index.php');
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Login - ATK</title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>

    <section class="vh-100">
        <div class="container-fluid">
            <div class="row">
            <div class="col-sm-6 text-black">

                <div class="px-5 ms-xl-4"></br></br>
                &nbsp;&nbsp;&nbsp;<img src="Images/dkjnew.png" alt="" width="50px">
                <!-- <i class="fas fa-pencil fa-2x me-3 pt-5 mt-xl-4" style="color: #709085;"></i> -->
                <!-- <span class="h1 fw-bold mb-0">E-ATK</span> -->
                </div>

                <div class="d-flex align-items-center h-custom-2 px-5 ms-xl-4 mt-5 pt-5 pt-xl-0 mt-xl-n5">
                    <form method="post" style="width: 23rem;">
                        <div class="container">
                            <h3 class="fw-normal mb-3 pb-3" style="letter-spacing: 1px;"><b>LOGIN | </b> E-ATK ONLINE</b></h3>
                            <form method="post">
                                <div class="form-outline mb-4">
                                    <label class="form-label" for="form2Example18">Username</label>
                                    <input type="text" id="inputUsername" class="form-control form-control-lg" name="username" autofocus/>
                                </div>

                                <div class="form-outline mb-4">
                                    <label class="form-label" for="form2Example28">Password</label>
                                    <input type="password" id="inputPassword" class="form-control form-control-lg" name="password"/>
                                </div>

                                <div class="col-md-12 mb-0  d-grid pt-1 mb-4">
                                    <!-- <button class="btn btn-info btn-lg btn-block" name="login" type="button">Login</button> -->
                                    <button type="submit btn btn-info btn-lg btn-block" class="btn btn-primary" name="login">Login</button>
                                    </br></br></br></br></br></br><p>Copyright &copy; PT Dunia Kimia Jaya - 2023</p>
                                </div>
                            </form>         
                        </div>                  
                    </form>
                </div>

            </div>
            <div class="col-sm-6 px-0 d-none d-sm-block">
                <img src="Images/login.jpg"
                alt="Login image" class="w-80 vh-100" style="object-fit: cover; object-position: left;">
            </div>
            </div>
        </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    </body>
</html>
