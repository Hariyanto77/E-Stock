<div class="col-md10 mb-3 bg-light mt-5 p-4 rounded">
                                        <h5>Dependent Drop Down List Using PHP and AJAX</h5>
                                        <form action="" method="POST">
                                            <div class="form-group">
                                                <select name="course" class="form-control form-control-lg" id="course">
                                                    <option value="" disabled selected>--Pilih Department--</option>
                                                    <?php
                                                        require_once 'action.php';
                                                        $sql="SELECT * FROM department ORDER BY department";
                                                        $result=mysqli_query($conn,$sql);
                                                        while($row=mysqli_fetch_array($result)){
                                                    ?>
                                                    <option value="<?= $row['id']; ?>"><?= $row['department']; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>


                                            
                                            <div class="form-group">
                                                <input type="submit" name="submit" value="SUBMIT" class="btn btn-danger btn-block btn-lg">
                                            </div>
                                        </form>
                                    </div>