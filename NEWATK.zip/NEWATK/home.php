<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ATK DKJ</title>
    <link rel="stylesheet" href="Library/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="Library/bootstrap/css/bootstrap.bundle.min.js">
    <link rel="stylesheet" href="Library/datepicker/css/datepicker.css">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <!-- Datepicker Library -->
    <script src="Library/datepicker/js/bootstrap-datepicker.js"></script>

    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bunt5dle.min.js"></script>

    <script src="text/javascript">
        $(document).ready(function(){
            $("#course").change(function(){
                var course_id=$(this).val();
                $.ajax({
                    url: "action.php",
                    method: "POST",
                    data: {courseID:course_id},
                    success: function(data){
                        $("language").html(data);
                    }
                });
            });
        });
    </script>

</head>
<body class="bg-dark">
    <div class="container">
        <div class="row my-4">
            <div class="col-lg-10 mx-auto">
                <div class="card shadow">
                    <div class="card-header ">
                        <h4>
                            Input Data
                        </h4>
                    </div>

                    <div class="card-body p-4">
                        <div id="show_alert"></div>
                        <form action="#" method="POST" id="add_form">
                            <div id="show_item">
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <input text="text" name="nama_pengambil[]" class="form-control" placeholder="Nama Pengambil" required>
                                    </div>

                                    <div class="col-md-12 mb-3">
                                        <select name="course" name="department[]" class="form-control form-control-md" id="course">
                                            <option value="" disabled selected>--Pilih Department--</option>
                                            <?php
                                                require_once 'action.php';
                                                $sql="SELECT * FROM department ORDER BY dept";
                                                $result=mysqli_query($conn,$sql);
                                                while($row=mysqli_fetch_array($result)){
                                            ?>
                                            <option value="<?= $row['id']; ?>"><?= $row['dept']; ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>

                                    <!-- <div class="col-md-12 mb-3">
                                        <input text="text" name="department[]" class="form-control" placeholder="Department" required>
                                    </div> -->

                                    <div class="col-md-12 mb-3">
                                        <input type="date" name="tanggal[]" class="form-control datepicker" required>
                                    </div>

                                    <!-- <div class="col-md-2 mb-3">
                                        <a class="btn btn-secondary dropdown-toggle" name="department[]" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            Department
                                        </a>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item" href="#">--Pilih Department--</a></li>
                                            <li><a class="dropdown-item" href="#">HRGA</a></li>
                                            <li><a class="dropdown-item" href="#">Maintenance</a></li>
                                            <li><a class="dropdown-item" href="#">Finance</a></li>
                                            <li><a class="dropdown-item" href="#">Accounting</a></li>
                                            <li><a class="dropdown-item" href="#">RND</a></li>
                                            <li><a class="dropdown-item" href="#">Logistik</a></li>
                                            <li><a class="dropdown-item" href="#">Produksi</a></li>
                                            <li><a class="dropdown-item" href="#">PPIC</a></li>
                                            <li><a class="dropdown-item" href="#">QC</a></li>
                                            <li><a class="dropdown-item" href="#">Marketing</a></li>
                                            <li><a class="dropdown-item" href="#">Purchasing</a></li>
                                            <li><a class="dropdown-item" href="#">QHSE</a></li>
                                        </ul>
                                    </div> -->
                                </div>

                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <input type="text" name="nama_barang[]" class="form-control" placeholder="Nama Barang" required>
                                    </div>

                                    <div class="col-md-12 mb-3">
                                        <input type="number" name="jumlah_barang[]" class="form-control" placeholder="Jumlah Barang" required>
                                    </div>
                                    <div class="col-md-12 mb-3 d-grid">
                                        <button class="btn btn-success add_item_btn">Add More</button>
                                    </div>
                                </div>
                            </div>

                            <div>
                                <input type="submit" value="Submit" class="btn btn-primary w-100" id="add-btn">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <script type="text/javascript">
        $(function(){
            $(".datepicker").datepicker({
                format: 'yyyy-mm-dd',
                autoclose: true,
                todayHighlight: true,
            });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <!-- <script>
        $(document).ready(function() {
            alert('Hello')
        });
    </script> -->
        
    <script>
        $(document).ready(function() {
            $(".add_item_btn").click(function(e) {
                e.preventDefault();
                $("#show_item").append
                                (`<div class="row append_item">
                                    <div class="col-md-12 mb-3">
                                        <input text="text" name="nama_barang[]" class="form-control" placeholder="Nama Barang" required>
                                    </div>

                                    <div class="col-md-12 mb-3">
                                        <input text="number" name="jumlah_barang[]" class="form-control" placeholder="Jumlah Barang" required>
                                    </div>

                                    <div class="col-md-2 mb-3 d-grid">
                                        <button class="btn btn-danger remove_item_btn">Hapus</button>
                                    </div>
                                </div>`);
            });

            $(document).on('click', '.remove_item_btn', function(e) {
                e.preventDefault();
                let row_item = $(this).parent().parent();
                $(row_item).remove();
                
            });

            // ajax request to insert all form data
            $("#add_form").submit(function(e) {
                e.preventDefault();
                $("#add_btn").val('Adding...');
                $.ajax({
                    url: 'action.php',
                    method: 'post',
                    data: $(this).serialize(),
                    success:function(response){
                        $("#add_btn").val('Add');
                        $("#add_form")[0].reset();
                        $(".append_item").remove();
                        $("#show_alert").html(`<div class="alert alert-success" role="alert">${response}</div>`);
                    }
                });
            });
        });
    </script>
</body>
</html>