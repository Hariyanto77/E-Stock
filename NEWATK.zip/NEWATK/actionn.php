<?php

$conn=mysqli_connect('localhost','root','hteeshy28','add_more');
 if(!$conn){
    die("Could not connect to the database : ".mysqli_connect_error());
 }

 ?>