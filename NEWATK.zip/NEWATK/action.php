<?php

// $conn=mysqli_connect('localhost','root','hteeshy28','depend');
// if(!$conn){
//     die("Could not connect to the database : ".mysqli_connect_error());
// }


// print_r($POST);
$conn = new PDO('mysql:host=localhost;dbname=add_more', 'root', 'hteeshy28');
if(!$conn){
    die("Could not connect to the database : ".mysqli_connect_error());
};

foreach($_POST['nama_barang'] as $key => $value){
    $sql = 'INSERT INTO items(nama_pengambil, nama_barang, jumlah_barang, department, tanggal) VALUES (:nama_pengambil, :barang, :jumlah, :dept, :tgl)';
    $stmt = $conn->prepare($sql);
    $stmt -> execute([
        'nama_pengambil' => $value,
        'dept' => $_POST['department'][$key],
        'tgl' => $_POST['tanggal'][$key],
        'barang' => $_POST['nama_barang'][$key],
        'jumlah' => $_POST['jumlah_barang'][$key]
    ]);   
}

echo 'Items Inserted Successfully!';