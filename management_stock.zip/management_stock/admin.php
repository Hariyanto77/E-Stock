<?php
    require 'dbconnect.php';
    require 'cek.php';
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Data Admin Login - IT</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
        <!-- Script CDN Bootstrap -->
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <h2><a class="navbar-brand ps-3" href="index.html">IT DKJ</a></h2>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <!-- <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                </div> -->
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <!-- <li><a class="dropdown-item" href="#!">Settings</a></li>
                        <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                        <li><hr class="dropdown-divider"/></li> -->
                        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="index.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Stock Barang
                            </a>
                            <a class="nav-link" href="brg_masuk.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Barang Masuk
                            </a>
                            <a class="nav-link" href="brg_keluar.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Barang Keluar
                            </a>
                            <a class="nav-link" href="report.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Report
                            </a>
                            <a class="nav-link" href="admin.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Kelola Admin
                            </a>
                            <a class="nav-link" href="logout.php">
                                Logout
                            </a>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Data Admin IT</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">
                            <script type='text/javascript'>                    
                                    var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                                    var myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
                                    var date = new Date();
                                    var day = date.getDate();
                                    var month = date.getMonth();
                                    var thisDay = date.getDay(),
                                        thisDay = myDays[thisDay];
                                    var yy = date.getYear();
                                    var year = (yy < 1000) ? yy + 1900 : yy;
                                    document.write(thisDay + ', ' + day + ' ' + months[month] + ' ' + year);		
                            </script>
                            <?php
                                date_default_timezone_set("Asia/jakarta");
                            ?>
                            | <b><span id="jam" style="font-size:24"></span></b>

                            <script type="text/javascript">
                                window.onload = function() { jam(); }
                            
                                function jam() {
                                    var e = document.getElementById('jam'),
                                    d = new Date(), h, m, s;
                                    h = d.getHours();
                                    m = set(d.getMinutes());
                                    s = set(d.getSeconds());
                            
                                    e.innerHTML = h +':'+ m +':'+ s;
                            
                                    setTimeout('jam()', 1000);
                                }
                            
                                function set(e) {
                                    e = e < 10 ? '0'+ e : e;
                                    return e;
                                }
                            </script>
                            </li>
                        </ol>

                        <?php
                            $ambildatastock = mysqli_query($conn, "select * from stock where stock < 1");

                            while($fetch=mysqli_fetch_array($ambildatastock)){
                                $barang = $fetch['namabarang'];
                        ?>                
                        <?php
                            }
                        ?>

                        <div class="card mb-4">
                            <div class="card-header">
                                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#myModal">
                                    + Tambah Admin Baru
                                </button>

                                <!-- Modal Tambah Admin Baru Dibawah-->
                            </div> 

                            <div class="card-body">
                                <table class="table-responsive">
                                <!-- <table class="table table-bordered" id="mauexport" width="100%" cellspacing="0"> -->
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Username Admin</th>
                                            <!-- <th>Kategori</th> -->
                                            <!-- <th>Merk</th> -->
                                            <!-- <th>Tipe</th>
                                            <th>Stock</th>
                                            <th>Satuan</th>
                                            <th>Lokasi</th> -->
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php
                                        $ambilsemuadataadmin = mysqli_query($conn, "select * from login");
                                        $i = 1;
                                        while($data=mysqli_fetch_array($ambilsemuadataadmin)){
                                            $iduser = $data['iduser'];
                                            $us = $data['username'];
                                            $pw = $data['password'];
                                            // $merk       = $data['merk'];
                                            // $tipe       = $data['tipe'];
                                            // $stock      = $data['stock'];
                                            // $satuan     = $data['satuan'];
                                            // $lokasi     = $data['lokasi'];
                                            // $idb        = $data['idbarang'];
                                        ?>
                                        <tr>
                                            <td><?=$i++;?></td>
                                            <td><?=$us;?></td>
                                            <!-- <td><?=$kategori;?></td> -->
                                            <!-- <td><?=$merk;?></td> -->
                                            <!-- <td><?=$tipe;?></td>
                                            <td><?=$stock;?></td>
                                            <td><?=$satuan;?></td>
                                            <td><?=$lokasi;?></td> -->
                                            <td>
                                                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#edit<?=$iduser;?>">
                                                    Edit
                                                </button>
                                                
                                                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete<?=$iduser;?>">
                                                    Delete
                                                </button>
                                            </td>
                                        </tr>
                                        
                                        <!-- Edit Modal body -->
                                        <div class="modal fade" id="edit<?=$iduser;?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">    
                                                    <!-- Modal Header -->
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Edit Barang</h4>
                                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    </div>
                                                    
                                                    <form method="post">
                                                    <div class="modal-body">
                                                        <label>Username</label>
                                                        <input type="text" name="usernameadmin" value="<?=$us;?>" placeholder="Masukkan Username Baru" class="form-control" required></br>
                                                        <label>Password</label>
                                                        <input type="password" name="passwordbaru" class="form-control" value="<?=$pw;?>" placeholder="Masukkan Password Baru"></br>               
                                                        <input type="hidden" name="id" value="<?=$iduser;?>">
                                                        <button type="submit" class="btn btn-success" name="updateadmin">Submit</button>
                                                    </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                    <!-- Delete Modal body -->
                                    <div class="modal fade" id="delete<?=$iduser;?>">
                                        <div class="modal-dialog">
                                        <div class="modal-content">   

                                            <!-- Modal Header -->
                                            <div class="modal-header">
                                                <h4 class="modal-title">Hapus Barang ?</h4>                                            
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                            <!-- Modal Body -->
                                                <form method="post">
                                                    <div class="modal-body">
                                                        Apakah Anda Yakin Ingin Menghapus username <b>"<?=$us;?>"</b> ini ?
                                                        <input type="hidden" name="id" value="<?=$iduser;?>">
                                                        </br></br>
                                                        <button type="submit" class="btn btn-danger" name="hapusadmin">Hapus</button>
                                                    </div>
                                                </form>
                                        </div>
                                    </div>
                                    </div>
                                        <?php
                                        };
                                        ?>
                                    </tbody>                                  
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; PT Dunia Kimia Jaya - 2023</div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>


    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#myModal">
        + Tambah Admin Baru
    </button>

    <div class="modal fade" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">    
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Tambah Admin</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                
                <!-- Modal body -->
                <form method="post">
                <div class="modal-body">
                    <label>Nama Admin</label>
                    <input type="text" name="username" placeholder="Masukkan Nama Admin Baru" class="form-control" required></br>
                    <label>Password Admin</label>
                    <input type="password" name="password" placeholder="Masukkan Nama Password Baru" class="form-control" required></br>

                    <button type="submit" class="btn btn-success" name="addadmin">Submit</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</html>
