-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 07, 2023 at 09:47 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stock_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `keluar`
--

CREATE TABLE `keluar` (
  `idkeluar` int(11) NOT NULL,
  `idbarang` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `keterangan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keluar`
--

INSERT INTO `keluar` (`idkeluar`, `idbarang`, `qty`, `tanggal`, `keterangan`) VALUES
(1, 1, 15, '2023-11-15 02:59:23', 'wer'),
(2, 2, 400, '2023-11-15 03:42:38', 'bbb'),
(11, 4, 10000, '2023-12-01 07:41:13', 'qwertyqwert'),
(12, 7, 1, '2023-12-07 04:46:31', 'asd');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `iduser` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`iduser`, `username`, `password`) VALUES
(1, 'it', 'it'),
(3, 'guestttt', 'ttt');

-- --------------------------------------------------------

--
-- Table structure for table `masuk`
--

CREATE TABLE `masuk` (
  `idmasuk` int(11) NOT NULL,
  `idbarang` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `keterangan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `masuk`
--

INSERT INTO `masuk` (`idmasuk`, `idbarang`, `qty`, `tanggal`, `keterangan`) VALUES
(1, 1, 0, '2023-11-15 01:32:54', 'penerima'),
(2, 1, 0, '2023-11-15 01:33:18', 'penerima'),
(3, 1, 300, '2023-11-15 02:00:50', 'hari'),
(4, 2, 200, '2023-11-15 03:42:22', 'vvv'),
(5, 2, 2, '2023-11-27 02:41:56', 'hariy'),
(6, 3, 3, '2023-11-27 06:16:06', 'gg'),
(7, 5, 100, '2023-11-27 06:24:27', 'asd'),
(8, 5, 2, '2023-11-28 03:44:12', '12'),
(9, 5, 200, '2023-11-28 08:18:56', 'asd'),
(10, 6, 50, '2023-11-28 08:26:10', 'hariyantooo00dddas'),
(21, 6, 1, '2023-12-01 07:10:34', 'hariyanto'),
(22, 6, 4, '2023-12-01 07:10:55', '33'),
(23, 7, 1, '2023-12-07 06:57:59', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `idbarang` int(11) NOT NULL,
  `namabarang` varchar(50) NOT NULL,
  `kategori` varchar(20) NOT NULL,
  `merk` varchar(20) NOT NULL,
  `tipe` varchar(20) NOT NULL,
  `stock` int(11) NOT NULL,
  `satuan` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `lokasi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`idbarang`, `namabarang`, `kategori`, `merk`, `tipe`, `stock`, `satuan`, `status`, `lokasi`) VALUES
(7, 'Pasta Processor ', 'Hardware', 'Deep Cool', 'Z5', 1, 'Pcs', 'Backup', 'DKJ Cikarang'),
(8, 'RAM Komputer ', 'Hardware', 'Hynix', '1RX8 PC3L 12800U', 1, 'Pcs', 'Backup', 'DKJ Cikarang'),
(9, 'RAM Laptop', 'Hardware', 'Elpida', '2GB 2RX8 PC3 10600S', 3, 'Pcs', 'Backup', 'DKJ Cikarang'),
(10, 'RAM Laptop', 'Hardware', 'V-GEN', '8GB 2RX8 PC3 12800S', 1, 'Pcs', 'Backup', 'DKJ Cikarang'),
(11, 'RAM Laptop', 'Hardware', 'Elpida', '2GB DDR 2/N800', 1, 'Pcs', 'Backup', 'DKJ Cikarang'),
(12, 'RAM Laptop', 'Hardware', 'ADATA', '1 GB 1RX8 PC2 6400', 1, 'Pcs', 'Backup', 'DKJ Cikarang'),
(13, 'RAM Laptop', 'Hardware', 'Elixir', '2GB 1RX8 PC3 10600S', 1, 'Pcs', 'Backup', 'DKJ Cikarang'),
(14, 'RAM Laptop', 'Hardware', 'Adata', '2GB 2RX8 PC3 10600S', 1, 'Pcs', 'Backup', 'DKJ Cikarang'),
(15, 'Ram Laptop', 'Hardware', 'Ramaxel', '512 MB DDR2', 1, 'Pcs', 'Tidak Dipakai', 'DKJ Cikarang'),
(16, 'Ram Laptop', 'Hardware', 'Kingston', '2GB 1RX8 PC3 10600S', 1, 'Pcs', 'Backup', 'DKJ Cikarang'),
(17, 'RAM Laptop', 'Hardware', 'Kingston', '4GB 1RX8 PC4 2400T', 1, 'Pcs', 'Backup', 'DKJ Cikarang'),
(18, 'RAM Komputer ', 'Hardware', 'Ramaxel', '4GB 1RX8 PC4 2400T', 1, 'Pcs', 'Backup', 'DKJ Cikarang'),
(19, 'RAM Komputer ', 'Hardware', 'Nanya', '2GB PC3 10600U', 1, 'Pcs', 'Backup', 'DKJ Cikarang'),
(20, 'RAM Komputer ', 'Hardware', 'Kingston', '2GB PC3 10600U', 1, 'Pcs', 'Backup', 'DKJ Cikarang'),
(21, 'RAM Komputer', 'Hardware', 'V-Gen', '4GB PC3 10600', 1, 'Pcs', 'Backup', 'DKJ Cikarang'),
(22, 'RAM Komputer', 'Hardware', 'V-Gen', '256MB PC3200', 1, 'Pcs', 'Tidak Dipakai', 'DKJ Cikarang'),
(23, 'RAM Komputer', 'Hardware', 'V-Gen', '256MB PC3200', 1, 'Pcs', 'Tidak Dipakai', 'DKJ Cikarang'),
(24, 'RAM Komputer', 'Hardware', 'Kingston', '1GB PC3 10600U', 1, 'Pcs', 'Tidak Dipakai', 'DKJ Cikarang'),
(25, 'RAM Komputer', 'Hardware', 'M', '1GB PC2 6400', 1, 'Pcs', 'Tidak Dipakai', 'DKJ Cikarang');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `keluar`
--
ALTER TABLE `keluar`
  ADD PRIMARY KEY (`idkeluar`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`iduser`);

--
-- Indexes for table `masuk`
--
ALTER TABLE `masuk`
  ADD PRIMARY KEY (`idmasuk`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`idbarang`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `keluar`
--
ALTER TABLE `keluar`
  MODIFY `idkeluar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `iduser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `masuk`
--
ALTER TABLE `masuk`
  MODIFY `idmasuk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `idbarang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
