<?php
session_start();

//Koneksi ke DB
$conn = mysqli_connect("localhost","root","hteeshy28","stock_management");

//Menambah Barang Baru
if(isset($_POST['addnewbarang'])){
    $namabarang = $_POST['namabarang'];
    $kategori= $_POST['kategori'];
    $merk = $_POST['merk'];
    $tipe = $_POST['tipe'];
    $stock = $_POST['stock'];
    $satuan = $_POST['satuan'];
    $lokasi = $_POST['lokasi'];

    $addtotable = mysqli_query($conn,"insert into stock (namabarang, kategori, merk, tipe, stock, satuan, lokasi) values ('$namabarang','$kategori','$merk','$tipe','$stock','$satuan','$lokasi')");
    if($addtotable){
        echo 'Sukses';
        header('location:index.php');
    } else {
        echo 'Gagal';
        header('location:index.php');
    }
}

//Menambah Barang Masuk
if(isset($_POST['barangmasuk'])){
    $barangnya = $_POST['barangnya'];
    $penerima  = $_POST['penerima'];
    $qty       = $_POST['qty'];

    $cekstocksekarang = mysqli_query($conn, "select * from stock where idbarang='$barangnya'");
    $ambildatanya     = mysqli_fetch_array($cekstocksekarang);

    $stocksekarang                        = $ambildatanya['stock'];
    $tambahkanstocksekarangdenganquantity = $stocksekarang + $qty;

    $addtomasuk       = mysqli_query($conn,"insert into masuk(idbarang, keterangan, qty) values ('$barangnya','$penerima','$qty')");
    $updatestockmasuk = mysqli_query($conn,"update stock set stock='$tambahkanstocksekarangdenganquantity' where idbarang='$barangnya'");

    if($addtomasuk){
        header('location:brg_masuk.php');
    } else {
        echo 'gagal';
        header('location:brg_masuk.php');
    }
}

//Menambah Barang Keluar
if(isset($_POST['barangkeluar'])){
    $barangnya = $_POST['barangnya'];
    $penerima  = $_POST['penerima'];
    $qty       = $_POST['qty'];

    $cekstocksekarang = mysqli_query($conn, "select * from stock where idbarang='$barangnya'");
    $ambildatanya     = mysqli_fetch_array($cekstocksekarang);

    $stocksekarang                        = $ambildatanya['stock'];
    $tambahkanstocksekarangdenganquantity = $stocksekarang - $qty;

    $addtokeluar      = mysqli_query($conn,"insert into keluar (idbarang, penerima, qty) values ('$barangnya','$penerima','$qty')");
    $updatestockmasuk = mysqli_query($conn,"update stock set stock='$tambahkanstocksekarangdenganquantity' where idbarang='$barangnya'");

    if($addtokeluar&&$updatestockmasuk){
        header('location:brg_keluar.php');
    } else {
        echo 'gagal';
        header('location:brg_keluar.php');
    }
}

//Update Info Barang
if(isset($_POST['updatebarang'])){
    $idb           =   $_POST['idb'];
    $namabarang    =   $_POST['namabarang'];
    $kategori      =   $_POST['kategori'];
    $merk          =   $_POST['merk'];
    $tipe          =   $_POST['tipe'];
    $stock         =   $_POST['stock'];
    $satuan        =   $_POST['satuan'];
    $lokasi        =   $_POST['lokasi'];

    $update  = mysqli_query($conn, "update stock set namabarang='$namabarang', kategori='$kategori', merk='$merk',
    tipe='$tipe', stock='$stock', satuan='$satuan', lokasi='$lokasi' where idbarang = '$idb'");
    if ($update){
        header('location:index.php');
    } else {
        echo 'Gagal';
        header('location:index.php');
    }
}

//Menghapus Barang Dari Stock
if(isset($_POST['hapusbarang'])){
    $idb = $_POST['idb'];
    $hapus = mysqli_query($conn, "delete from stock where idbarang= '$idb'");
    if ($hapus){
        header('location:index.php');
    } else {
        echo 'Gagal';
        header('location:index.php');
    }
}
?>